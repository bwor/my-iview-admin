<template>
  <div>
    upload-ajax

    <bwor-upload v-model="pic" @success="handleUploadSuccess"></bwor-upload>
  </div>
</template>

<script>
import Upload from "@/components/upload/index.vue";
export default {
  name: "",
  props: [""],
  data() {
    return {
      pic: "",
    };
  },

  components: { "bwor-upload": Upload },

  computed: {},

  beforeMount() {},

  mounted() {},

  methods: {
    handleUploadSuccess(data) {
      this.pic = data.imgName || "";
    },
  },

  watch: {},
};
</script>
<style lang='' scoped>
</style>