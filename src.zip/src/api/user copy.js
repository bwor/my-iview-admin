import axios from '@/utils/request'

export const getUserInfo = async () => {
  return await axios.get('/user/getUserInfo')
}
export const getTechnology = async () => {
  return await axios.get('/user/getTechnology')
}
export const getCompanes = async () => {
  return await axios.get('/user/getCompanes')
}
export const getProjectes = async () => {
  return await axios.get('/user/getProjectes')
}
