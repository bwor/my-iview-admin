import Icons from './icons.vue'
export default Icons
