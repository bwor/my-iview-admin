import TagsNav from './tags-nav.vue'
export default TagsNav
